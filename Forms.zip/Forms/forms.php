<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forms</title>
</head>
<body>
    Welcome <?php echo $_REQUEST["name"]; ?> <br>
    You are <?php echo $_REQUEST["age"]; ?> years old.
    Your email is <?php echo $_REQUEST["email"]; ?>
    
</body>
</html>